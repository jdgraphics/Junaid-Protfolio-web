<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <link rel="profile" href="http://gmpg.org/xfn/11" />
    <link rel="pingback" href="http://zohaibanwer.com/xmlrpc.php" />

        <link rel="shortcut icon" href="" type="image/x-icon" />
    <link rel="apple-touch-icon" href="">
    <link rel="apple-touch-icon" sizes="120x120" href="">
    <link rel="apple-touch-icon" sizes="76x76" href="">
    <link rel="apple-touch-icon" sizes="152x152" href="">

<title>Page not found &#8211; Zohaib Anwer</title>
<style rel="stylesheet" property="stylesheet" type="text/css">.ms-loading-container .ms-loading, .ms-slide .ms-slide-loading { background-image: none !important; background-color: transparent !important; box-shadow: none !important; } #header .logo { max-width: 170px; } @media (min-width: 1170px) { #header .logo { max-width: 250px; } } @media (max-width: 991px) { #header .logo { max-width: 110px; } } @media (max-width: 767px) { #header .logo { max-width: 110px; } } #header.sticky-header .logo { max-width: 100px; }</style><link rel='dns-prefetch' href='//cdnjs.cloudflare.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Zohaib Anwer &raquo; Feed" href="http://zohaibanwer.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Zohaib Anwer &raquo; Comments Feed" href="http://zohaibanwer.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/zohaibanwer.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.4.2"}};
			/*! This file is auto-generated */
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://zohaibanwer.com/wp-includes/css/dist/block-library/style.min.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://zohaibanwer.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css'  href='http://zohaibanwer.com/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='porto-bootstrap-css'  href='http://zohaibanwer.com/wp-content/themes/porto/css/bootstrap_1.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='porto-plugins-css'  href='http://zohaibanwer.com/wp-content/themes/porto/css/plugins_1.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='porto-theme-elements-css'  href='http://zohaibanwer.com/wp-content/themes/porto/css/theme_elements_1.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='porto-theme-css'  href='http://zohaibanwer.com/wp-content/themes/porto/css/theme_1.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='porto-skin-css'  href='http://zohaibanwer.com/wp-content/themes/porto/css/skin_1.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='porto-style-css'  href='http://zohaibanwer.com/wp-content/themes/porto/style.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='porto-google-fonts-css'  href='//fonts.googleapis.com/css?family=Open+Sans%3A200%2C300%2C400%2C700%2C800%2C600%2C%7CShadows+Into+Light%3A200%2C300%2C400%2C700%2C800%2C600%2C%7C&#038;subset=cyrillic%2Ccyrillic-ext%2Cgreek%2Cgreek-ext%2Ckhmer%2Clatin%2Clatin-ext%2Cvietnamese&#038;ver=5.4.2' type='text/css' media='all' />
<!--[if lt IE 10]>
<link rel='stylesheet' id='porto-ie-css'  href='http://zohaibanwer.com/wp-content/themes/porto/css/ie.css?ver=5.4.2' type='text/css' media='all' />
<![endif]-->
<script type='text/javascript' src='http://zohaibanwer.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='http://zohaibanwer.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='//cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js?ver=5.4.2'></script>
<script type='text/javascript' src='http://zohaibanwer.com/wp-content/themes/porto/js/plugins.min.js?ver=4.0.5'></script>
<link rel='https://api.w.org/' href='http://zohaibanwer.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://zohaibanwer.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://zohaibanwer.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.4.2" />
<script async src="//static.zotabox.com/b/9/b9b6c553b6cd19d6683029ef19a84d6e/widgets.js"></script><style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="http://zohaibanwer.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">

    <script type="text/javascript">
        
                    
                    </script>
</head>
<body class="error404 full blog-1  wpb-js-composer js-comp-ver-5.4.2 vc_responsive">
    
    <div class="page-wrapper"><!-- page wrapper -->

        
                    <div class="header-wrapper clearfix"><!-- header wrapper -->
                                
                    <header id="header" class="header-corporate header-10 search-sm">
    
    <div class="header-main header-body" style="top: 0px;">
        <div class="header-container container">
            <div class="header-left">
                <div class="logo">    <a href="http://zohaibanwer.com/" title="Zohaib Anwer - Graphic Designer &#8211; work well as a team member or work independently, as required and adapt easily to new situations, scenarios, and places." rel="home">
                <span class="logo-text">Zohaib Anwer</span>            </a>
    </div>            </div>

            <div class="header-right">
                <div class="header-right-top">
                    <div class="header-contact"><ul class="nav nav-pills nav-top">
	<li>
		<a href="#" target="_blank"><i class="fa fa-angle-right"></i>About Us</a> 
	</li>
	<li>
		<a href="#" target="_blank"><i class="fa fa-angle-right"></i>Contact Us</a> 
	</li>
	<li class="phone">
		<span><i class="fa fa-phone"></i>(123) 456-7890</span>
	</li>
</ul>
</div>    <div class="searchform-popup">
        <a class="search-toggle"><i class="fa fa-search"></i></a>
            <form action="http://zohaibanwer.com/" method="get"
        class="searchform ">
        <fieldset>
            <span class="text"><input name="s" id="s" type="text" value="" placeholder="Search&hellip;" autocomplete="off" /></span>
                        <span class="button-wrap"><button class="btn btn-special" title="Search" type="submit"><i class="fa fa-search"></i></button></span>
        </fieldset>
    </form>
        </div>
                    </div>
                <div class="header-right-bottom">
                    <div id="main-menu">
                                            </div>
                    
                    <a class="mobile-toggle"><i class="fa fa-reorder"></i></a>
                </div>

                
            </div>
        </div>

        
<div id="nav-panel" class="">
    <div class="container">
        <div class="mobile-nav-wrap">
                    </div>
    </div>
</div>
    </div>
</header>
                            </div><!-- end header wrapper -->
        
        
                <section class="page-top page-header-1">
        
<div class="container">
    <div class="row">
        <div class="col-md-12">
            
                <div class="breadcrumbs-wrap">
                    <ul class="breadcrumb"><li class="home"itemscope itemtype="http://schema.org/BreadcrumbList"><a itemprop="url" href="http://zohaibanwer.com" title="Go to Home Page"><span itemprop="title">Home</span></a><i class="delimiter"></i></li><li>404</li></ul>
                </div>
            
            <div class="">
                <h1 class="page-title">404 - Page Not Found</h1>
                
            </div>
            
        </div>
    </div>
</div>    </section>
    
        <div id="main" class="column1 boxed"><!-- main -->

            
                        <div class="container">
                            
            
            <div class="row main-content-wrap">

            <!-- main content -->
            <div class="main-content col-md-12">

                            

<div id="content" class="no-content">
    <div class="container">
        <section class="page-not-found">
            <div class="row">
                <div class="col-md-6 col-md-offset-1">
                    <div class="page-not-found-main">
                        <h2 class="entry-title">404 <i class="fa fa-file"></i></h2>
                        <p>We're sorry, but the page you were looking for doesn't exist.</p>
                    </div>
                </div>
                                    <div class="col-md-4">
                                            </div>
                            </div>
        </section>
    </div>
</div>

        

</div><!-- end main content -->


    </div>
</div>


        
            
            </div><!-- end main -->

            
            <div class="footer-wrapper ">

                
                    
<div id="footer" class="footer-1">
    
        <div class="footer-bottom">
        <div class="container">
                        <div class="footer-left">
                                © Copyright 2019. All Rights Reserved. Developed by <a href="https://peergraphics.com/" target="_blank">Peer Graphics</a>            </div>
            
            
                    </div>
    </div>
    </div>
                
            </div>

        
    </div><!-- end wrapper -->
    

<!--[if lt IE 9]>
<script src="http://zohaibanwer.com/wp-content/themes/porto/js/html5shiv.min.js"></script>
<script src="http://zohaibanwer.com/wp-content/themes/porto/js/respond.min.js"></script>
<![endif]-->

<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/zohaibanwer.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='http://zohaibanwer.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.0.5'></script>
<script type='text/javascript' src='http://zohaibanwer.com/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=5.4.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var js_porto_vars = {"rtl":"","ajax_url":"http:\/\/zohaibanwer.com\/wp-admin\/admin-ajax.php","change_logo":"1","container_width":"1140","grid_gutter_width":"30","show_sticky_header":"1","show_sticky_header_tablet":"1","show_sticky_header_mobile":"1","ajax_loader_url":"\/\/zohaibanwer.com\/wp-content\/themes\/porto\/images\/ajax-loader@2x.gif","category_ajax":"","prdctfltr_ajax":"","show_minicart":"1","slider_loop":"1","slider_autoplay":"1","slider_autoheight":"1","slider_speed":"5000","slider_nav":"","slider_nav_hover":"1","slider_margin":"","slider_dots":"1","slider_animatein":"","slider_animateout":"","product_thumbs_count":"4","product_zoom":"1","product_zoom_mobile":"1","product_image_popup":"1","zoom_type":"inner","zoom_scroll":"1","zoom_lens_size":"200","zoom_lens_shape":"square","zoom_contain_lens":"1","zoom_lens_border":"1","zoom_border_color":"#888888","zoom_border":"0","screen_lg":"1170","mfp_counter":"%curr% of %total%","mfp_img_error":"<a href=\"%url%\">The image<\/a> could not be loaded.","mfp_ajax_error":"<a href=\"%url%\">The content<\/a> could not be loaded.","popup_close":"Close","popup_prev":"Previous","popup_next":"Next","request_error":"The requested content cannot be loaded.<br\/>Please try again later."};
/* ]]> */
</script>
<script type='text/javascript' src='http://zohaibanwer.com/wp-content/themes/porto/js/theme.min.js?ver=4.0.5'></script>
<script type='text/javascript' src='http://zohaibanwer.com/wp-includes/js/wp-embed.min.js?ver=5.4.2'></script>
			<script type="text/javascript">
				jQuery.noConflict();
				(function( $ ) {
					$(function() {
						// More code using $ as alias to jQuery
						$("area[href*=\\#],a[href*=\\#]:not([href=\\#]):not([href^='\\#tab']):not([href^='\\#quicktab']):not([href^='\\#pane'])").click(function() {
							if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
								var target = $(this.hash);
								target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
								if (target.length) {
								$('html,body').animate({
								scrollTop: target.offset().top - 20  
								},900 ,'easeInQuint');
								return false;
								}
							}
						});
					});
				})(jQuery);	
			</script>				
				
    <script type="text/javascript">
        
                    var lastScrollTop = 0;

	jQuery(window).on('scroll', function(){
	   var st = jQuery(this).scrollTop();
	   
	   if (st > lastScrollTop){
	   		jQuery('.img_plx img').css({
	   			transform: 'translate(0, -'+ st +'px)'
	   		});
	   } else {
	      jQuery('.img_plx img').css({
	   			transform: 'translate(0, '+ -Math.abs(st) +'px)'
	   		});
	   }
	   lastScrollTop = st;
	});
	
	
jQuery('#aboutMeMoreBtn').on('click', function() {
		jQuery(this).hide();
		jQuery('#aboutMeMore').toggleClass('about-me-more-visible');
	});
	
jQuery(document).ready(function(){
	jQuery('.post-block.post-share').each(function(){
    	var this_ = jQuery(this);
      	this_.insertAfter( this_.parent() );
      	this_.prepend('<span class="custom-share-text font-weight-semibold text-color-dark">SHARE:</span>');
    });
});
                    </script>
</body>
</html>
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/


Served from: zohaibanwer.com @ 2020-07-10 07:59:03 by W3 Total Cache
-->